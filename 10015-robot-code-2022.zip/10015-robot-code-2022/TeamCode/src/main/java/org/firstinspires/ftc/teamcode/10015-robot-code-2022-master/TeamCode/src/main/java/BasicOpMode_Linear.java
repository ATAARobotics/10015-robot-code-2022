/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * This file contains an minimal example of a Linear "OpMode". An OpMode is a 'program' that runs in either
 * the autonomous or the teleop period of an FTC match. The names of OpModes appear on the menu
 * of the FTC Driver Station. When an selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 *
 * This particular OpMode just executes a basic Tank Drive Teleop for a two wheeled robot
 * It includes all the skeletal structure that all linear OpModes contain.
 *
 * Use Android Studios to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this opmode to the Driver Station OpMode list
 */

@TeleOp(name="Basic: Linear OpMode", group="Linear Opmode")
//@Disabled
public class BasicOpMode_Linear extends LinearOpMode {

    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor leftDrive = null;
    private DcMotor rightDrive = null;
    private DcMotor intakeDrive = null;
    private DcMotorSimple duckDrive = null;
    private DcMotor linear_lift = null;
    private Servo dumpster = null;
    private Servo clampr = null;
    private Servo clampl = null;
    private Servo claw = null;
    private DcMotor sparkmini = null;
    private Servo arm = null;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        // Initialize the hardware variables. Note that the strings used here as parameters
        // to 'get' must correspond to the names assigned during the robot configuration
        // step (using the FTC Robot Controller app on the phone).
        leftDrive  = hardwareMap.get(DcMotor.class, "l_motor");
        rightDrive = hardwareMap.get(DcMotor.class, "r_motor");
        intakeDrive = hardwareMap.get(DcMotor.class, "INT");
        duckDrive = hardwareMap.get(DcMotorSimple.class, "duck_motor");
        clampl = hardwareMap.get(Servo.class, "clampl");
        clampr = hardwareMap.get(Servo.class, "clampr");
        arm = hardwareMap.get(Servo.class, "arm");
        dumpster = hardwareMap.get(Servo.class, "dumpster");
        claw = hardwareMap.get(Servo.class, "claw");
        linear_lift = hardwareMap.get(DcMotor.class, "linear_lift");

        // Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        leftDrive.setDirection(DcMotor.Direction.FORWARD);
        rightDrive.setDirection(DcMotor.Direction.REVERSE);
        linear_lift.setDirection(DcMotor.Direction.FORWARD);

        linear_lift.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        linear_lift.setTargetPosition(3000);

        linear_lift.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        linear_lift.setPower(0.0);

        linear_lift.setTargetPosition(0);
        // Wait for the game to start (driver presses PLAY)
        waitForStart();
        runtime.reset();
        Boolean Intake_Positive = false;
        Boolean Intake_Negative = false;
        Boolean GP2_prev_A = false;
        Boolean GP2_prev_B = false;
        Boolean GP2_prev_Y = false;
        Boolean GP2_prev_LB = false;
        Boolean GP2_prev_RB = false;
        Boolean Duck_Plate = false;
        Boolean GP1_prev_A = false;
        long clawtiming = 0;
        Boolean clawtimerrun = false;
        //Boolean GP2_prev_DPR = false;
        int linear_lift_target = 0;
        int lift = 0;
        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            // Setup a variable for each drive wheel to save power level for telemetry

            double leftPower;
            double rightPower;
            // Choose to drive using either Tank Mode, or POV Mode
            // Comment out the method that's not used.  The default below is POV.

            // POV Mode uses left stick to go forward, and right stick to turn.
            // - This uses basic math to combine motions and is easier to drive straight.
            double drive = -gamepad1.left_stick_y;
            double turn = gamepad1.right_stick_x;
            double deadzone = 0.25;

            if (-deadzone < drive && drive < deadzone) drive = 0.0;
            if (-deadzone < turn && turn < deadzone) turn = 0.0;
            leftPower = Range.clip(drive + turn, -1.0, 1.0);
            rightPower = Range.clip(drive - turn, -1.0, 1.0);
            // Send calculated power to wheels
            leftDrive.setPower(leftPower);
            rightDrive.setPower(rightPower);

            if (gamepad2.a && !GP2_prev_A) {
                telemetry.addData("A Button", "IPos (%b), INeg (%b)", Intake_Positive, Intake_Negative);
                Intake_Positive = !Intake_Positive;
                Intake_Negative = false;

                if (Intake_Positive) {
                    intakeDrive.setPower(1);
                } else {
                    intakeDrive.setPower(0);
                }
            }
            GP1_prev_A = gamepad1.a;
            if (gamepad2.b && !GP2_prev_B) {
                telemetry.addData("B Button", "IPos (%b), INeg (%b)", Intake_Positive, Intake_Negative);
                Intake_Negative = !Intake_Negative;
                Intake_Positive = false;
                if (Intake_Negative) {
                    intakeDrive.setPower(-1);
                } else {
                    telemetry.addLine("Stopping Intake");
                    intakeDrive.setPower(0);
                }
            }

            GP2_prev_B = gamepad2.b;
            //---------------------------------------------------------------//
            //duckDrive coding session//
            if (gamepad2.y && !GP2_prev_Y) {
                Duck_Plate = !Duck_Plate;
                if (Duck_Plate) {
                    duckDrive.setPower(0.45);
                } else {
                    duckDrive.setPower(0.0);
                }
            }
            GP2_prev_Y = gamepad2.y;

            lift = linear_lift_target;
            if (gamepad2.left_bumper){
                if (!GP2_prev_LB) {
                    linear_lift.setPower(0.45);
                    linear_lift_target = lift + 2700;
                    if (linear_lift_target > 2700) {
//                        linear_lift.setPower(0.00);
                        linear_lift_target = 0;
                    }
                }
            }
            linear_lift.setTargetPosition(linear_lift_target);
            GP2_prev_LB = gamepad2.left_bumper;

            if (gamepad2.right_bumper) {
                if (!GP2_prev_RB && linear_lift_target >10) {
                    linear_lift.setPower(0.45);
                    linear_lift_target = lift - 2700;
                }
            }
            GP2_prev_RB = gamepad2.right_bumper;

            //if above 100 close claw unless the claw is set to be open
            if (linear_lift.getCurrentPosition() >= 2600){
                dumpster.setPosition(0.8);
            }
            else {
                dumpster.setPosition(0.04);
            }

            if (linear_lift.getCurrentPosition() <= 100 && !GP1_prev_A){
                claw.setPosition(0.38);
            }
            else if (linear_lift.getCurrentPosition() > 100 && !GP1_prev_A) {
                claw.setPosition(0.6);
            }
            else{
                claw.setPosition(0.36);
            }


           // if (gamepad2.dpad_right) {
                //if (!GP2_prev_DPR) {
                   // arm.setPosition(-1);
                   // clampr.setPosition(1);
                   // clampl.setPosition(-1);
                //}
            //}
           // else{
               // arm.setPosition(0);
              //  clampr.setPosition(-1);
               // clampl.setPosition(1);
            //}
          //  GP2_prev_DPR = gamepad2.dpad_right;

            telemetry.addData("Lift", "Target: " + linear_lift_target);
            // Show the elapsed game time and wheel power.
            telemetry.addData("Status", "Run Time: " + runtime.toString());
//            telemetry.addData("Motors", "left (%.2f), right (%.2f)", leftPower, rightPower);
            telemetry.addData("Lift Position", "Lift (%d)", linear_lift.getCurrentPosition());
            telemetry.addData("Claw Position", "claw (%.2f)", claw.getPosition());
            telemetry.addData("dumpster Position", "dumpster (%.2f)", dumpster.getPosition());
            telemetry.update();

        }
    }
}
